MotorNote ingestion test
